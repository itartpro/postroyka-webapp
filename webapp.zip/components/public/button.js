import css from "./button.module.css";

export const Button = () => {

    return (
        <div className={` ${css.but}`}>
            <button>Показать ещё ¬</button>
        </div>
    )
}