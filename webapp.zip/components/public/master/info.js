import css from './info.module.css';

export const Info = props => {
    return (
        <section>
            <b>Об исполнителе</b>
        </section>
    )
}