export default function Footer() {
    return (
        <footer>Footer</footer>
    )
}