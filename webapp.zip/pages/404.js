import NotFound from 'components/not-found';

export default function Custom404() {
    return <NotFound/>
}