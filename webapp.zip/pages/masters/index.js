import PublicLayout from "components/public/public-layout";

const Masters = () => {
    return (
        <PublicLayout>
            <main className="col start max">
                <h1>Страница фильтра по мастерам</h1>
            </main>
        </PublicLayout>
    )
}

export default Masters